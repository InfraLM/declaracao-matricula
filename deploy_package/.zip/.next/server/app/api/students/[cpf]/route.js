var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/students/[cpf]/route.js")
R.c("server/chunks/[root-of-the-server]__94487ff0._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__3f2ff3e3._.js")
R.c("server/chunks/[root-of-the-server]__58ae2488._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/_next-internal_server_app_api_students_[cpf]_route_actions_d58e0500.js")
R.m(34518)
module.exports=R.m(34518).exports
