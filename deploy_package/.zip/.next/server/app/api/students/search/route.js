var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/students/search/route.js")
R.c("server/chunks/[root-of-the-server]__389f1340._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__3f2ff3e3._.js")
R.c("server/chunks/[root-of-the-server]__58ae2488._.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/_next-internal_server_app_api_students_search_route_actions_1371fbfa.js")
R.m(77220)
module.exports=R.m(77220).exports
