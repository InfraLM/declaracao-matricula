module.exports=[59771,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_busca_page_actions_6d97c8e1.js.map