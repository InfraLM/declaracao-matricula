module.exports=[58525,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_aluno_%5Bcpf%5D_page_actions_a73f9eab.js.map