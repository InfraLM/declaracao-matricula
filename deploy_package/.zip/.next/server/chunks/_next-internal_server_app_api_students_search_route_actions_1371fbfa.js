module.exports=[91455,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_students_search_route_actions_1371fbfa.js.map