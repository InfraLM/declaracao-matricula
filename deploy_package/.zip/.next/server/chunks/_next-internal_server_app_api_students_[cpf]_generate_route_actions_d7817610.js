module.exports=[68163,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_students_%5Bcpf%5D_generate_route_actions_d7817610.js.map