module.exports=[16672,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_students_%5Bcpf%5D_route_actions_d58e0500.js.map